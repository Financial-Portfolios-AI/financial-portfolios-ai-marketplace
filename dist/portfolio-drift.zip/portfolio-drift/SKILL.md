---
name: portfolio-drift
description: "Compare the user's real brokerage holdings against a Financial Portfolios AI model portfolio and report the drift. Reports only; proposes no trades."
---

<!-- Generated from automations/templates.yaml by scripts/build.py. Do not edit. -->

# How far my account has drifted

Requires the Financial Portfolios AI connector.

1. Read positions read-only from a connected brokerage or aggregator. If none is connected,
   ask the user to paste `ticker,quantity` rows instead. Never ask for credentials.
2. `get_portfolio_allocation` for the model.
3. Show a table of model weight, account weight and difference, largest first. Flag names
   held in only one of the two.
4. Stop there. Prepare no orders. If they want to act, offer the "align my account" journey.

## Always

- Financial Portfolios AI data is informational and educational only: never a recommendation,
  advice or a suitability assessment.
- A portfolio with `delayed: true` is the public book, about 45 days old: give its `as_of` date
  and never present it as current.
- Performance comes from `get_portfolio_performance` / `get_portfolio_metrics`; include their
  `disclaimer` in full and unaltered. If the user supplies their own prices and asks for a
  recalculation, you may work it out from the `get_portfolio_history` weights, held forward between
  snapshots, but label it as the user's own hypothetical calculation from their data - never the
  publisher's figure - and say it may differ from the website.
- Attribute anything taken from another connector (news, prices, positions) to that connector.
